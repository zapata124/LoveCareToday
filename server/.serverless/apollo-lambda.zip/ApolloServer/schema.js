"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// import { gql } from 'apollo-server';
const apollo_server_lambda_1 = require("apollo-server-lambda");
const typeDefs = (0, apollo_server_lambda_1.gql) `
scalar JSON
type Search {
  description: String,
  ein: String,
  name: String,
  profileUrl: String,
  logoUrl: String,
  coverImageUrl: String,
  logoCloudinaryId: String,
  matchedTerms: [String],
  slug: String,
  location: String,
  websiteUrl: String,
  tags: [String],
}
type Nonprofit {
  id: String,
  tagName: String,
  causeCategory: String,
  title: String,
  tagImageCloudinaryId: String,
  tagUrl: String,
  tagImageUrl: String,
}
type Cause {
  description: String,
  name: String,
  profileUrl: String,
  logoUrl: String,
  coverImageUrl: String,
  logoCloudinaryId: String,
  matchedTerms: [String],
  slug: String,
  location: String,
  tags: [String],
}
type Query {
  search(search: String, take: Int): [Search]
}
type Query {
  nonprofit(take: Int): [Nonprofit]
}
type Query {
  cause(browse: String): [Cause]
}
`;
exports.default = typeDefs;
