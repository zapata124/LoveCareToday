"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const apollo_server_1 = require("apollo-server");
const typeDefs = (0, apollo_server_1.gql) `
type Search {
  description: String,
  ein: String,
  name: String,
  profileUrl: String,
  logoUrl: String,
  coverImageUrl: String,
  logoCloudinaryId: String,
  matchedTerms: [String],
  slug: String,
  location: String,
  websiteUrl: String,
  tags: [String],
}
type Nonprofit {
  id: String,
  tagName: String,
  causeCategory: String,
  title: String,
  tagImageCloudinaryId: String,
  tagUrl: String,
  tagImageUrl: String,
}
type Cause {
  description: String,
  name: String,
  profileUrl: String,
  logoUrl: String,
  coverImageUrl: String,
  logoCloudinaryId: String,
  matchedTerms: [String],
  slug: String,
  location: String,
  tags: [String],
}
type Query {
  search(search: String, take: Int): [Search]
}
type Query {
  nonprofit(take: Int): [Nonprofit]
}
type Query {
  cause(browse: String, take: Int): [Cause]
}
`;
exports.default = typeDefs;
