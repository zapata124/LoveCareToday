"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const apollo_server_1 = require("apollo-server");
const dotenv_1 = __importDefault(require("dotenv"));
const schema_1 = __importDefault(require("./schema"));
const keys = dotenv_1.default.config().parsed;
const { APIkey, URL } = keys;
const resolvers = {
    Query: {
        search: async (_, { search, take }) => {
            try {
                const res = await fetch(`https://${URL}/search/${search}?take=${take}&apiKey=${APIkey}`);
                const data = await res.json();
                const nonprofits = data.nonprofits;
                return nonprofits;
            }
            catch (err) {
                console.log(err);
            }
        },
        nonprofit: async (_, { take }) => {
            try {
                console.log('server');
                const res = await fetch(`https://${URL}/nonprofit/maps?take=${take}apiKey=${APIkey}`);
                const data = await res.json();
                const nonprofit = data.data.nonprofitTags;
                return nonprofit;
            }
            catch (err) {
                console.log(err);
            }
        },
        cause: async (_, { browse }) => {
            try {
                const res = await fetch(`https://${URL}/browse/${browse}?apiKey=${APIkey}`);
                const data = await res.json();
                const nonprofit = data.nonprofits;
                return nonprofit;
            }
            catch (err) {
                console.log(err);
            }
        },
    },
};
// we might need to change this to express
const server = new apollo_server_1.ApolloServer({
    typeDefs: schema_1.default,
    resolvers,
    csrfPrevention: true,
    cache: 'bounded',
});
// The `listen` method launches a web server.
server.listen().then(({ url }) => {
    console.log(`🚀  Server ready at ${url}`);
});
