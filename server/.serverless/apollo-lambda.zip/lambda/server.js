"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.graphqlHandler = void 0;
const apollo_server_lambda_1 = require("apollo-server-lambda");
const dotenv_1 = __importDefault(require("dotenv"));
const schema_1 = __importDefault(require("../ApolloServer/schema"));
const axios_1 = __importDefault(require("axios"));
const URL = 'https://partners.every.org/v0.2';
const keys = dotenv_1.default.config().parsed;
const { APIkey } = keys;
// const APIkey = 'pk_live_4d17374d4c171f0f91524140256c6bc3'
const resolvers = {
    Query: {
        search: async (_, { search, take }) => {
            try {
                const res = await axios_1.default.get(`${URL}/search/${search}?take=${take}&apiKey=${APIkey}`);
                const nonprofits = await res.data.nonprofits;
                return nonprofits;
            }
            catch (err) {
                console.log(err);
            }
        },
        nonprofit: async (_, { take }) => {
            try {
                const res = await axios_1.default.get(`${URL}/nonprofit/maps?take=${take}apiKey=${APIkey}`);
                const nonprofit = await res.data.data.nonprofitTags;
                return nonprofit;
            }
            catch (err) {
                console.log(err);
            }
        },
        cause: async (_, { browse }) => {
            try {
                const res = await axios_1.default.get(`${URL}/browse/${browse}?apiKey=${APIkey}`);
                const nonprofit = await res.data.nonprofits;
                return nonprofit;
            }
            catch (err) {
                console.log(err);
            }
        },
    },
};
// we might need to change this to express
const server = new apollo_server_lambda_1.ApolloServer({
    typeDefs: schema_1.default,
    resolvers,
    csrfPrevention: true,
    cache: 'bounded',
});
exports.graphqlHandler = server.createHandler();
